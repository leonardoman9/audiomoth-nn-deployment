# Empty C Example
This example project shows an empty configuration that can be used as a starting point to add components and functionality.